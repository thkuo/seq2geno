#!/bin/bash
#$ -V
#$ -l h_core=15
#$ -l h_vmem=300G

cd __
source activate snakemake_env
seq2geno -f ./seq2geno_inputs.yml
